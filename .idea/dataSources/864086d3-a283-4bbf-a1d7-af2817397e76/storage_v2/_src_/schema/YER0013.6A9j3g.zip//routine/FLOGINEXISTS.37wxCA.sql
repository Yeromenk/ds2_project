create function FLoginExists(p_login Student.login%type) return boolean as
    v_cnt int;
begin
    select count(*) into v_cnt
    from STUDENT
        where LOGIN = p_login;

    if v_cnt > 0 then
        return True;
    else
        return false;
    end if;
end;
/

