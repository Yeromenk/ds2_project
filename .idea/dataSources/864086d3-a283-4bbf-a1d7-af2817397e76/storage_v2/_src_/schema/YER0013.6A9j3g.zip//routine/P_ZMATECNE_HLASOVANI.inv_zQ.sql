create procedure P_Zmatecne_hlasovani AS
declare
    v_sql varchar2(1000);
    v_cnt int;
begin
    select count(*)
    into v_cnt
    from USER_TAB_COLUMNS
    where TABLE_NAME = 'Hlasovani';

    if v_cnt = 0 then
        v_sql := 'Alter table Hlasovani add zmatecne_hlasovani char(1)';
        execute immediate v_sql;
    end if;

    v_sql := 'Update Hlasovani set zmatecne_hlasovani = 1 where id_hlasovani in (select id_hlasovani from zmatecne';
    execute immediate v_sql;

    v_sql := 'Update Hlasovani set zmatecne_hlasovani = 0 where id_hlasovani in (select id_hlasovani from zmatecne';
    execute immediate v_sql;

    v_sql := 'Drop table zmatecne_hlasovani';
    execute immediate v_sql;
end;
/

