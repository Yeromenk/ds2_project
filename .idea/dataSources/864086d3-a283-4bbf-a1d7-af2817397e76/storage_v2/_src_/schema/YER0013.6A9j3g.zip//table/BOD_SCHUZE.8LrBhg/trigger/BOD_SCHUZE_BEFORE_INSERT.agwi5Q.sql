create trigger BOD_SCHUZE_BEFORE_INSERT
    before insert
    on BOD_SCHUZE
    for each row
DECLARE
  schuze_datum DATE;
  organ_datum DATE;
  pocet_bodu NUMBER;
    v_exc exception ;
BEGIN
  -- Získání aktuálního data
  SELECT CURRENT_DATE INTO schuze_datum;

  -- Kontrola platnosti schůze
  SELECT od_schuze, do_schuze
  INTO schuze_datum, organ_datum
  FROM schuze
  WHERE id_schuze = :NEW.id_schuze;

  IF schuze_datum > schuze_datum OR schuze_datum < organ_datum THEN
    DBMS_OUTPUT.PUT_LINE('Error with schuze count');
    raise v_exc;
  END IF;

  -- Kontrola platnosti orgánu
  SELECT od_organ, do_organ
  INTO organ_datum
  FROM organ
  WHERE id_organ = :NEW.id_organ;

  IF organ_datum > schuze_datum OR organ_datum < schuze_datum THEN
    DBMS_OUTPUT.PUT_LINE('Error with schuze count');
    raise v_exc;
  END IF;

  -- Získání počtu bodů v dané schůzi
  SELECT COUNT(*) INTO pocet_bodu
  FROM bod_schuze
  WHERE id_schuze = :NEW.id_schuze;

  -- Nastavení atributu bod
  :NEW.bod := pocet_bodu + 1;

  -- Nastavení atributu uplny_naz
  IF :NEW.UPLNY_naz IS NULL OR pocet_bodu = 0 THEN
    :NEW.uplny_naz := 'Uvodni bod';
  END IF;
END;
/

