create function FAddStudent3(p_fname Student.fname%TYPE, p_lname Student.lname%TYPE,
                                        p_email Student.email%TYPE, p_grade Student.grade%TYPE,
                                        p_dateOfBirth Student.date_of_birth%TYPE) return varchar as
    v_login Student.login%type;
begin
    v_login := FGetLogin(p_lname);

    insert into STUDENT(login, fname, lname, email, grade, date_of_birth)
    VALUES (v_login, p_fname, p_lname, p_email, p_grade, p_dateOfBirth);
    return v_login;

exception
    when others then
        return 'error';
end;
/

