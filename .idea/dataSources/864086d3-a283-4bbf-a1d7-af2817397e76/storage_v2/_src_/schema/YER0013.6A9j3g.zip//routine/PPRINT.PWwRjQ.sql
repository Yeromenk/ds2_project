create procedure PPrint(p_text varchar2) as
begin
    DBMS_OUTPUT.PUT_LINE(p_text);
end;
/

