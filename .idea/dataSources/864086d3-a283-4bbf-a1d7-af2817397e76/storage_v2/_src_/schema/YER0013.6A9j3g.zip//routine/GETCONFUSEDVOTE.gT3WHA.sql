create function GetConfusedVote(p_id_osoba number) return number as
    v_osoba OSOBA%rowtype;
    v_cnt   int;
begin
    select *
    into v_osoba
    from OSOBA
    where ID_OSOBA = p_id_osoba;

    select count(*)
    into v_cnt
    from OSOBA
             join ZMATECNE_HLASOVANI_POSLANEC on ZMATECNE_HLASOVANI_POSLANEC.ID_OSOBA = OSOBA.ID_OSOBA
             join HLASOVANI on HLASOVANI.ID_HLASOVANI = ZMATECNE_HLASOVANI_POSLANEC.ID_HLASOVANI
    where extract(year from HLASOVANI.DATUM) = 2012
      and ZMATECNE_HLASOVANI_POSLANEC.ID_OSOBA = p_id_osoba
      and ZMATECNE_HLASOVANI_POSLANEC.MODE_ = 1;

    DBMS_OUTPUT.PUT_LINE('Osoba je a ma ' || v_cnt);
    return v_cnt;
exception
    when others then
        DBMS_OUTPUT.PUT_LINE('Osoba neexistuje');
        return -1;
end;
/

