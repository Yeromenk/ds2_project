create trigger ZADANI
    before insert
    on BOD_SCHUZE
    for each row
DECLARE
    v_schuze_count NUMBER;
    v_organ_count  NUMBER;
    v_exc EXCEPTION;
BEGIN
    SELECT COUNT(*)
    INTO v_schuze_count
    FROM SCHUZE
    WHERE :NEW.datum NOT BETWEEN OD_SCHUZE AND DO_SCHUZE;

    IF v_schuze_count > 0 THEN
        RAISE v_exc;
        DBMS_OUTPUT.PUT_LINE('Error with schuze count');
    END IF;

    SELECT COUNT(*)
    INTO v_organ_count
    FROM ORGAN
    WHERE :NEW.DATUM NOT BETWEEN OD_ORGAN AND DO_ORGAN;

    IF v_organ_count > 0 THEN
        RAISE v_exc;
        DBMS_OUTPUT.PUT_LINE('Error with organ count');
    END IF;

    SELECT NVL(MAX(BOD), 0) + 1
    INTO :NEW.bod
    FROM BOD_SCHUZE
    WHERE ID_SCHUZE = :NEW.id_schuze;

    IF :NEW.UPLNY_NAZ IS NULL OR :NEW.bod = 1 THEN
        :NEW.UPLNY_NAZ := 'Uvodny bod';
    END IF;
END;
/

