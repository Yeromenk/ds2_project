create procedure PAddStudent1(p_login STUDENT.login%type, p_fname STUDENT.fname%type,
                                         p_lname STUDENT.lname%type, p_email student.email%type,
                                         p_grade student.grade%type, p_dateOfBirth student.DATE_OF_BIRTH%type) as
begin
    insert into STUDENT (LOGIN, FNAME, LNAME, EMAIL, GRADE, DATE_OF_BIRTH)
    VALUES (p_login, p_fname, p_lname, p_email, p_grade, p_dateOfBirth);
end;
/

