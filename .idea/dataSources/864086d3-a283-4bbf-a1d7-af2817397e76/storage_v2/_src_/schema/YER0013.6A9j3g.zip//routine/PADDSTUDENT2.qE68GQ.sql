create procedure PAddStudent2(p_fname STUDENT.fname%type,
                                         p_lname STUDENT.lname%type, p_email student.email%type,
                                         p_grade student.grade%type, p_dateOfBirth student.DATE_OF_BIRTH%type) as
    v_login STUDENT.login%type;
begin
    v_login := lower(substr(p_lname, 1, 3) || 000);

    insert into STUDENT (LOGIN, FNAME, LNAME, EMAIL, GRADE, DATE_OF_BIRTH)
    VALUES (v_login, p_fname, p_lname, p_email, p_grade, p_dateOfBirth);
end;
/

