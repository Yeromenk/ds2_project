create procedure PSendEmail(p_email varchar2, p_subject varchar2, p_body varchar2) as
begin
    PPrint('--------------------------------------------------------');
    PPrint('email to: ' || p_email || ', subject: ' || p_subject);
    PPrint(p_body);
    PPrint('--------------------------------------------------------');
end;
/

