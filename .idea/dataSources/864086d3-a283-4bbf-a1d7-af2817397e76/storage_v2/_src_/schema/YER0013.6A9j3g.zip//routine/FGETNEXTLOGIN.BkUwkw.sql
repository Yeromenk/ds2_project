create function FGetNextLogin(p_lname Student.login%type) return varchar as
    v_i     int;
    v_login varchar(6);
begin
    v_i := 1;

    loop
        v_login := lower(substr(p_lname, 1, 3) || lpad(v_i, 3, '0'));
        exit when not FLOGINEXISTS(v_login);
        v_i := v_i + 1;
    end loop;

    return v_login;

end;
/

