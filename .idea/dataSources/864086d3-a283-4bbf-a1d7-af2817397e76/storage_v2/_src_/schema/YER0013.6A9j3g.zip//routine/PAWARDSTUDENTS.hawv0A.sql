create procedure PAwardStudents(p_year int, p_amount number) as
    v_i      int;
    v_amount number := p_amount;
begin
    for c_student in (
        select STUDENT_LOGIN, sum(points) as pts
        from STUDENTCOURSE
        where year = p_year
        group by STUDENT_LOGIN
        order by pts desc
        )
        loop
            exit when v_i >= 5;

            update student
            set account_balance = account_balance + v_amount
            where login = c_student.STUDENT_LOGIN;

            v_amount := v_amount / 2;
            v_i := v_amount / 2;

        end loop;
end;
/

