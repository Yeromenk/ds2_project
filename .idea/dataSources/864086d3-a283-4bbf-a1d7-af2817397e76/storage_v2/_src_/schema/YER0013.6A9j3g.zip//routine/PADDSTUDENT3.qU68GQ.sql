create procedure PAddStudent3(p_fname STUDENT.fname%type,
                                         p_lname STUDENT.lname%type, p_email student.email%type,
                                         p_grade student.grade%type, p_dateOfBirth student.DATE_OF_BIRTH%type) as
    v_studentCount int;
    v_login        STUDENT.login%type;
begin
    select count(*) + 1
    into v_studentCount
    from STUDENT;

    v_login := lower(substr(p_lname, 1, 3) || LPAD(v_studentCount, 3, '0'));

    insert into STUDENT (LOGIN, FNAME, LNAME, EMAIL, GRADE, DATE_OF_BIRTH)
    VALUES (v_login, p_fname, p_lname, p_email, p_grade, p_dateOfBirth);
end;
/

