create FUNCTION F_SET_ZARAZENI_ORG(
    p_id_osoba  NUMBER,
    p_id_organ  NUMBER,
    p_set  CHAR
) RETURN CHAR AS
    v_result CHAR(1);
    v_cnt int;
BEGIN
    select count(*) 
    into v_cnt
    from organ
    where id_organ = p_id_organ;

    IF v_cnt = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Neplatne ID organu');
        RETURN 'E'; 
    END IF;

    select count(*)
    into v_cnt
    from zarazeni 
    where id_osoba = p_id_osoba and id_of = p_id_organ;

    IF p_set = 'Y' THEN
        IF v_cnt = 0 THEN
            INSERT INTO ZARAZENI (ID_OSOBA, ID_OF, OD_O)
            VALUES (p_id_osoba, p_id_organ, SYSDATE);
            v_result := 'I'; 
        ELSE
            v_result := 'N'; 
        END IF;
    ELSIF p_set = 'N' THEN
        IF v_cnt = 1 THEN
            DELETE FROM ZARAZENI
            WHERE ID_OSOBA = p_id_osoba AND ID_OF = p_id_organ;
            v_result := 'D'; 
        ELSE
            v_result := 'N';
        END IF;
    ELSE
        v_result := 'E';
    END IF;

    RETURN v_result;
END;
/

