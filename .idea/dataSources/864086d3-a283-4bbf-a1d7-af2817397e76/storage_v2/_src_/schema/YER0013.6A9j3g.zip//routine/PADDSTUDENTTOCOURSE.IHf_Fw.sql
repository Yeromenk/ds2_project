create procedure PAddStudentToCourse(p_student_login STUDENT.login%type, p_course_code COURSE.code%type,
                                                p_year int) as
    v_capacity int;
    v_cnt      int;
begin
    select CAPACITY
    into v_capacity
    from COURSE
    where code = p_course_code;

    select count(*)
    into v_cnt
    from COURSE
    where code = p_course_code;

    if v_capacity > v_cnt then
        insert into STUDENTCOURSE(student_login, course_code, year) VALUES (p_student_login, p_course_code, p_year);
    else
        DBMS_OUTPUT.PUT_LINE('Kapacita kurzu byla prekrocena');
    end if;

end;
/

