create PROCEDURE SetVoteLevel(p_od DATE, p_do DATE) AS
BEGIN
    FOR c_schuze IN (
        SELECT id_schuze, COUNT(*) AS pts
        FROM SCHUZE
                 JOIN HLASOVANI ON HLASOVANI.ID_HLASOVANI = SCHUZE.ID_SCHUZE
        WHERE DATUM BETWEEN p_od AND p_do
        GROUP BY id_schuze
        )
        LOOP
              dbms_output.put_line(c_schuze.ID_SCHUZE || ' , ' || c_schuze.pts);
            IF c_schuze.pts < 100 THEN
                UPDATE SCHUZE
                SET vote_level = 'I'
                WHERE id_schuze = c_schuze.id_schuze;
            ELSIF c_schuze.pts < 1000 THEN
                UPDATE SCHUZE
                SET vote_level = 'M'
                WHERE id_schuze = c_schuze.id_schuze;
            ELSE
                UPDATE SCHUZE
                SET vote_level = 'H'
                WHERE id_schuze = c_schuze.id_schuze;
            END IF;

        END LOOP;
END;
/

