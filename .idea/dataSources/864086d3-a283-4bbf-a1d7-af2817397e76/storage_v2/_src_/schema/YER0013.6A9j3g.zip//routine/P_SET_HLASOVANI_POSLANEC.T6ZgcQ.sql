create procedure P_Set_Hlasovani_Poslanec (p_id_hlasovani Hlasovani.id_hlasovani%type, p_id_poslanec Poslanec.id_poslanec%type, p_vysledek varchar) as
    v_cnt int;
begin
    select count(*) into v_cnt
    from hlasovani_poslanec
    where id_hlasovani = p_id_hlasovani
    and id_poslanec = p_id_poslanec;

    if v_cnt = 0 then
        insert into hlasovani_poslanec (id_hlasovani, id_poslanec, vysledek )
        values (p_id_hlasovani, p_id_poslanec, p_vysledek);
    else
        update hlasovani_poslanec 
        set vysledek = p_vysledek
        where id_hlasovani = p_id_hlasovani and id_poslanec = p_id_poslanec;
    end if;

    update hlasovani 
    set pro = (select count(*) from hlasovani_poslanec where id_hlasovani = p_id_hlasovani and hlasovani_poslanec.vysledek = 'A'), 
    proti = (select count(*) from hlasovani_poslanec where id_hlasovani = p_id_hlasovani and hlasovani_poslanec.vysledek = 'B')
    where id_hlasovani = p_id_hlasovani;
end;
/

