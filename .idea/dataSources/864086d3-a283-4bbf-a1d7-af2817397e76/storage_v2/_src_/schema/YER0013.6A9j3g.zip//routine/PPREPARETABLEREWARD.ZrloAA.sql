create procedure PPrepareTableReward as
    v_cnt int;
begin
    select count(*)
    into v_cnt
    from user_tables
    where table_name = 'Reward';

    if v_cnt > 0 then
        execute immediate ('Drop table Reward');
    end if;

    EXECUTE IMMEDIATE ('
CREATE TABLE Reward
(
    id INTEGER PRIMARY KEY,
    student_login CHAR(6) REFERENCES Student,
    winter_reward INTEGER NULL,
    summer_reward INTEGER NULL,
    thesis_reward INTEGER NULL
)');
end;
/

