create procedure SetAbsenceLevel(p_od date, p_do date) as
begin
    for c_poslanec in (
        select POSLANEC.id_poslanec, count(*) as pts
        from POSLANEC
                 join omluva on omluva.ID_POSLANEC = POSLANEC.ID_POSLANEC
        where OMLUVA.den between p_od and p_do
        group by POSLANEC.id_poslanec
        )
        loop
        dbms_output.put_line(c_poslanec.id_poslanec || ' , ' || c_poslanec.pts);
            if c_poslanec.pts < 11 then
                update POSLANEC
                set POSLANEC.absence_level = 'L'
                where POSLANEC.ID_POSLANEC = c_poslanec.ID_POSLANEC;
            elsif c_poslanec.pts < 21 then
                update POSLANEC
                set POSLANEC.absence_level = 'M'
                where POSLANEC.ID_POSLANEC = c_poslanec.ID_POSLANEC;
            else
                update POSLANEC
                set POSLANEC.absence_level = 'H'
                where POSLANEC.ID_POSLANEC = c_poslanec.ID_POSLANEC;
            end if;
        end loop; 
end;
/

