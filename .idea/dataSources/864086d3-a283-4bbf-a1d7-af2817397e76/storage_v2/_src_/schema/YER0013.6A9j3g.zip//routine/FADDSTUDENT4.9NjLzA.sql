create function FAddStudent4(p_fname Student.fname%TYPE, p_lname Student.lname%TYPE,
                                        p_email Student.email%TYPE, p_grade Student.grade%TYPE,
                                        p_dateOfBirth Student.date_of_birth%TYPE) return varchar as
    v_login         Student.login%type;
    v_gradeCapacity int;
    v_cnt           int;
begin
    v_login := FGetLogin(p_lname);

    if p_grade = 1 then
        v_gradeCapacity := 20;
    elsif
        p_grade = 2 then
        v_gradeCapacity := 15;
    else
        v_gradeCapacity := 10;
    end if;

    select count(*)
    into v_cnt
    from student
    where grade = p_grade;

    if v_cnt >= v_gradeCapacity then
        return 'full';
    end if;

    insert into STUDENT(login, fname, lname, email, grade, date_of_birth)
    VALUES (v_login, p_fname, p_lname, p_email, p_grade, p_dateOfBirth);
    return v_login;

exception
    when others then
        return 'error';
end;
/

