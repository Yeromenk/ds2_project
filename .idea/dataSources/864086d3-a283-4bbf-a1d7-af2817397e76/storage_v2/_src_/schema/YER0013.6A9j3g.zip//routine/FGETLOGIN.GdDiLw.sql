create function FGetLogin(p_lname Student.lname%type) return student.login%type as
    v_studentCount int;
begin
    select count(*) + 1
    into v_studentCount
    from STUDENT;

    return lower(substr(p_lname, 1, 3) || LPAD(v_studentCount, 3, '0'));
end;
/

