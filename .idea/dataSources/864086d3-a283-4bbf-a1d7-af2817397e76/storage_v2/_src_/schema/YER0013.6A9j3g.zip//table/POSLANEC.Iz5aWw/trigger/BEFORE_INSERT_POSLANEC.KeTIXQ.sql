create trigger BEFORE_INSERT_POSLANEC
    before insert
    on POSLANEC
    for each row
declare
    v_umrti    date;
    v_do_organ date;
    v_ex exception ;
begin
    select UMRTI
    into v_umrti
    from OSOBA
    where OSOBA.ID_OSOBA = :new.id_osoba;

    if v_umrti is not null then

        raise v_ex;
    end if;

    select DO_ORGAN
    into v_do_organ
    from ORGAN
    where ORGAN.ID_ORGAN = :new.id_organ;

    if v_do_organ is not null and v_do_organ < current_timestamp then

        raise v_ex;
    end if;

    :new.id_kandidatka := -1;

    if :new.obec = 'Praha' then
        :new.id_kraj := 1;
    elsif :new.obec = 'Brno' then
        :new.id_kraj := 2;
    elsif :new.obec = 'Ostrava' then
        :new.id_kraj := 3;
    end if;
end;
/

